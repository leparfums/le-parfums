L&E PARFUMS - PUBLICACIÓN GRATUITA

1. Entrá a https://github.com y creá una cuenta.
2. Creá un repositorio llamado le-parfums.
3. Subí index.html, style.css, script.js y la carpeta images.
4. Settings > Pages > Deploy from a branch > main > /(root) > Save.
5. GitHub te dará una dirección tipo https://TUUSUARIO.github.io/le-parfums/

IMPORTANTE: editá script.js antes de publicar:
- WHATSAPP = tu número de Uruguay.
- INSTAGRAM = tu Instagram.
- precios, notas y productos.
Para fotos: colocá las imágenes en images y poné en cada producto, por ejemplo:
img:"images/khamrah.jpg"
