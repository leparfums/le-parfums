// EDITÁ ESTOS DATOS
const WHATSAPP="59800000000"; // Uruguay: 598 + número
const INSTAGRAM="https://www.instagram.com/"; // poné tu Instagram

const products=[
{name:"Khamrah",brand:"Lattafa",cat:"unisex",price:"Consultar",notes:"Canela, dátiles, praliné, vainilla y haba tonka.",img:""},
{name:"Club de Nuit Intense",brand:"Armaf",cat:"masculino",price:"Consultar",notes:"Cítricos, piña, abedul, almizcle y vainilla.",img:""},
{name:"Yara Candy",brand:"Lattafa",cat:"femenino",price:"Consultar",notes:"Frutal, dulce, cremoso y avainillado.",img:""},
{name:"Bade'e Al Oud Noble Blush",brand:"Lattafa",cat:"femenino",price:"Consultar",notes:"Dulce, floral, vainilla y maderas.",img:""},
{name:"De La Voie",brand:"Perfume",cat:"unisex",price:"Consultar",notes:"Consultá disponibilidad y notas.",img:""}
];

const wa=p=>`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hola L&E Parfums, quiero consultar por "+p)}`;
function render(f="todos"){document.querySelector("#products").innerHTML=products.filter(p=>f==="todos"||p.cat===f).map(p=>`<article class="card"><div class="pic">${p.img?`<img src="${p.img}" alt="${p.name}">`:`<div class="fake">L&E</div>`}</div><div class="info"><div class="tag">${p.brand} · ${p.cat}</div><h3>${p.name}</h3><p class="notes">${p.notes}</p><div class="price">${p.price}</div><a class="buy" target="_blank" href="${wa(p.name)}">CONSULTAR / COMPRAR</a></div></article>`).join("")}
document.querySelectorAll(".filters button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");render(b.dataset.f)});
document.querySelector("#wa").href=wa("un perfume");document.querySelector("#ig").href=INSTAGRAM;document.querySelector("#year").textContent=new Date().getFullYear();render();